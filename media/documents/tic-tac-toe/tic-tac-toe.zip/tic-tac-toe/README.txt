Author: Vinush
Contact: decurvavia@gmail.com
------
# Starting the game

run "tic-tac-toe-ui.exe" to play the game